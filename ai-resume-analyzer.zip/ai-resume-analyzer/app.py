"""AI Resume Analyzer & ATS Score Generator -- Streamlit application entry point."""

from __future__ import annotations

import os
import sqlite3
from datetime import datetime

import pandas as pd
import streamlit as st

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from modules.report_generator import generate_report
from modules.resume_analyzer import run_full_analysis
from modules.utils import (
    AppConfig,
    ExtractionError,
    FileValidationError,
    validate_file,
)

# --------------------------------------------------------------------------
# Page config & theme
# --------------------------------------------------------------------------

st.set_page_config(
    page_title="AI Resume Analyzer & ATS Score Generator",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded",
)

PRIMARY = "#5B4FE9"
SECONDARY = "#2E6FF2"
ACCENT = "#8B7CF6"

CUSTOM_CSS = f"""
<style>
    .main {{ background-color: #F7F8FC; }}
    .score-card {{
        background: linear-gradient(135deg, {PRIMARY} 0%, {SECONDARY} 100%);
        color: white; padding: 1.5rem; border-radius: 16px; text-align: center;
        box-shadow: 0 4px 14px rgba(91, 79, 233, 0.25);
    }}
    .score-card h1 {{ font-size: 3rem; margin: 0; color: white; }}
    .score-card p {{ margin: 0; opacity: 0.9; }}
    .metric-card {{
        background: white; padding: 1rem 1.25rem; border-radius: 12px;
        border: 1px solid #E5E7F5; box-shadow: 0 2px 6px rgba(0,0,0,0.04);
    }}
    .badge {{
        display: inline-block; padding: 0.2rem 0.7rem; border-radius: 999px;
        font-size: 0.8rem; font-weight: 600; margin: 0.15rem;
    }}
    .badge-match {{ background: #DCFCE7; color: #16A34A; }}
    .badge-partial {{ background: #FEF9C3; color: #CA8A04; }}
    .badge-missing {{ background: #FEE2E2; color: #DC2626; }}
    .section-title {{ color: {PRIMARY}; font-weight: 700; }}
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

PAGES = [
    "Home",
    "Upload Resume",
    "Job Description",
    "Resume Analysis",
    "ATS Score",
    "Keyword Analysis",
    "AI Recommendations",
    "Job Match",
    "Download Report",
]

TARGET_ROLES = [
    "Software Developer", "Python Developer", "Java Developer",
    "Cloud Engineer", "Data Analyst", "AI/ML Engineer", "GenAI Engineer",
]


def _init_state():
    defaults = {
        "resume_bytes": None,
        "resume_filename": None,
        "job_description": "",
        "target_role": TARGET_ROLES[0],
        "use_ai": True,
        "analysis_result": None,
        "analysis_error": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


_init_state()
config = AppConfig.load()


# --------------------------------------------------------------------------
# Optional SQLite history
# --------------------------------------------------------------------------


def _init_db():
    try:
        os.makedirs(os.path.dirname(config.db_path) or ".", exist_ok=True)
        conn = sqlite3.connect(config.db_path)
        conn.execute(
            """CREATE TABLE IF NOT EXISTS analysis_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT,
                filename TEXT,
                overall_score INTEGER,
                target_role TEXT
            )"""
        )
        conn.commit()
        conn.close()
    except Exception:
        pass  # History is optional; never block the app on DB issues.


def _save_history(filename: str, overall_score: int, target_role: str):
    try:
        conn = sqlite3.connect(config.db_path)
        conn.execute(
            "INSERT INTO analysis_history (created_at, filename, overall_score, target_role) "
            "VALUES (?, ?, ?, ?)",
            (datetime.now().isoformat(timespec="seconds"), filename, overall_score, target_role),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


_init_db()


# --------------------------------------------------------------------------
# Sidebar navigation
# --------------------------------------------------------------------------

st.sidebar.title("📄 Resume Analyzer")
st.sidebar.caption("AI-powered ATS scoring & resume feedback")
page = st.sidebar.radio("Navigate", PAGES, label_visibility="collapsed")

st.sidebar.divider()
st.sidebar.toggle("Use Claude AI analysis", key="use_ai", help="Turn off to see deterministic scoring only.")
if not config.anthropic_api_key:
    st.sidebar.warning("No ANTHROPIC_API_KEY set. AI features will be unavailable until you configure .env.")

if st.session_state.analysis_result:
    s = st.session_state.analysis_result.score_breakdown["overall_score"]
    st.sidebar.metric("Last ATS Score", f"{s}/100")


def run_analysis():
    """Run the full pipeline and store the result (and any error) in session state."""
    st.session_state.analysis_error = None
    st.session_state.analysis_result = None
    try:
        validate_file(
            st.session_state.resume_filename,
            len(st.session_state.resume_bytes),
            config.max_file_size_mb,
        )
        with st.spinner("Analyzing your resume..."):
            result = run_full_analysis(
                filename=st.session_state.resume_filename,
                file_bytes=st.session_state.resume_bytes,
                job_description=st.session_state.job_description,
                target_role=st.session_state.target_role,
                use_ai=st.session_state.use_ai and bool(config.anthropic_api_key),
            )
        st.session_state.analysis_result = result
        _save_history(
            st.session_state.resume_filename,
            result.score_breakdown["overall_score"],
            st.session_state.target_role,
        )
    except FileValidationError as exc:
        st.session_state.analysis_error = str(exc)
    except ExtractionError as exc:
        st.session_state.analysis_error = str(exc)
    except ValueError as exc:
        st.session_state.analysis_error = str(exc)
    except Exception as exc:  # noqa: BLE001
        st.session_state.analysis_error = f"Something went wrong while analyzing your resume: {exc}"


# --------------------------------------------------------------------------
# Page: Home
# --------------------------------------------------------------------------

if page == "Home":
    st.title("📄 AI Resume Analyzer & ATS Score Generator")
    st.markdown(
        "Upload your resume, optionally paste a job description, and get a "
        "transparent ATS score, keyword analysis, and AI-powered improvement "
        "suggestions -- all in one dashboard."
    )
    cols = st.columns(4)
    features = [
        ("📤", "Upload", "PDF or DOCX resumes, parsed into structured fields."),
        ("🎯", "ATS Score", "Transparent, weighted 0-100 score. Never randomly generated."),
        ("🔑", "Keywords", "Matched, missing, and additional keyword analysis."),
        ("🤖", "AI Suggestions", "Actionable, resume-grounded recommendations from Claude."),
    ]
    for col, (icon, title, desc) in zip(cols, features):
        with col:
            st.markdown(f"### {icon} {title}")
            st.caption(desc)

    st.divider()
    st.subheader("Get started")
    st.markdown("Use the sidebar to go to **Upload Resume**, then optionally add a **Job Description** before running the analysis.")

# --------------------------------------------------------------------------
# Page: Upload Resume
# --------------------------------------------------------------------------

elif page == "Upload Resume":
    st.title("📤 Upload Resume")
    uploaded = st.file_uploader("Upload your resume (PDF or DOCX)", type=["pdf", "docx"])
    if uploaded is not None:
        st.session_state.resume_bytes = uploaded.getvalue()
        st.session_state.resume_filename = uploaded.name
        st.success(f"Loaded **{uploaded.name}** ({len(st.session_state.resume_bytes) / 1024:.1f} KB)")

    st.session_state.target_role = st.selectbox(
        "Target role (used for the generated summary)", TARGET_ROLES,
        index=TARGET_ROLES.index(st.session_state.target_role),
    )

    if st.session_state.resume_bytes:
        if st.button("Run Analysis", type="primary"):
            run_analysis()

    if st.session_state.analysis_error:
        st.error(st.session_state.analysis_error)
    elif st.session_state.analysis_result:
        st.info("Analysis complete! Go to **Resume Analysis**, **ATS Score**, or other pages in the sidebar to view results.")

# --------------------------------------------------------------------------
# Page: Job Description
# --------------------------------------------------------------------------

elif page == "Job Description":
    st.title("📋 Job Description")
    st.caption("Optional -- add a job description for keyword matching and job-fit scoring.")
    st.session_state.job_description = st.text_area(
        "Paste the job description here", value=st.session_state.job_description, height=300,
        placeholder="Paste the full job description text...",
    )
    if st.session_state.resume_bytes:
        if st.button("Re-run Analysis with this Job Description", type="primary"):
            run_analysis()
    else:
        st.info("Upload a resume first on the **Upload Resume** page.")

# --------------------------------------------------------------------------
# Shared guard for result-dependent pages
# --------------------------------------------------------------------------

elif page in ("Resume Analysis", "ATS Score", "Keyword Analysis", "AI Recommendations", "Job Match", "Download Report"):
    result = st.session_state.analysis_result
    if not result:
        st.title(page)
        if st.session_state.analysis_error:
            st.error(st.session_state.analysis_error)
        st.warning("No analysis yet. Upload a resume on **Upload Resume** and click **Run Analysis** first.")
    else:
        resume = result.parsed_resume
        score = result.score_breakdown

        if page == "Resume Analysis":
            st.title("🧾 Resume Analysis")

            c1, c2 = st.columns([1, 2])
            with c1:
                st.markdown("#### Contact Information")
                st.write(f"**Name:** {resume.name or '_Not detected_'}")
                st.write(f"**Email:** {resume.email or '_Not detected_'}")
                st.write(f"**Phone:** {resume.phone or '_Not detected_'}")
                st.write(f"**Location:** {resume.location or '_Not detected_'}")
                st.write(f"**LinkedIn:** {resume.linkedin or '_Not detected_'}")
                st.write(f"**GitHub:** {resume.github or '_Not detected_'}")
            with c2:
                st.markdown("#### Summary")
                st.write(resume.summary or "_No summary section detected._")
                st.markdown("#### Skills")
                st.write(", ".join(resume.skills) if resume.skills else "_No skills section detected._")

            tabs = st.tabs(["Experience", "Internships", "Projects", "Education", "Certifications", "Achievements"])
            sections = [resume.experience, resume.internships, resume.projects,
                        resume.education, resume.certifications, resume.achievements]
            for tab, items in zip(tabs, sections):
                with tab:
                    if items:
                        for item in items:
                            st.markdown(f"- {item}")
                    else:
                        st.caption("Nothing detected in this section.")

            st.divider()
            st.markdown("#### Resume Strength Analysis")
            sa = result.strength_analysis
            colA, colB, colC = st.columns(3)
            with colA:
                st.markdown("**Strong sections**")
                st.write(", ".join(sa.strong_sections) or "None")
                st.markdown("**Generic statements**")
                st.write(", ".join(sa.generic_statements) or "None found")
            with colB:
                st.markdown("**Weak sections**")
                st.write(", ".join(sa.weak_sections) or "None")
                st.markdown("**Overused words**")
                st.write(", ".join(sa.repeated_words) or "None found")
            with colC:
                st.markdown("**Missing sections**")
                st.write(", ".join(sa.missing_sections) or "None")
                st.markdown("**Formatting problems**")
                st.write("; ".join(sa.formatting_problems) or "None found")

            if sa.quantification_opportunities:
                st.markdown("**Quantification opportunities** (bullets claiming impact with no numbers):")
                for q in sa.quantification_opportunities:
                    st.markdown(f"- {q}")

        elif page == "ATS Score":
            st.title("🎯 ATS Score")
            st.markdown(
                f'<div class="score-card"><h1>{score["overall_score"]}</h1>'
                f'<p>Overall ATS Score / 100</p></div>',
                unsafe_allow_html=True,
            )
            st.progress(score["overall_score"] / 100)
            st.caption(
                "Weighted from keyword match (30%), skills (20%), experience (15%), "
                "projects (10%), structure (10%), education/certs (5%), formatting (5%), "
                "and contact info (5%)."
            )
            st.divider()

            metrics = [
                ("Keyword Match", score["keyword_score"]),
                ("Skills Score", score["skills_score"]),
                ("Experience Score", score["experience_score"]),
                ("Project Score", score["project_score"]),
                ("Structure Score", score["structure_score"]),
                ("Education/Cert Score", score["education_score"]),
                ("Formatting Score", score["formatting_score"]),
                ("Contact Score", score["contact_score"]),
            ]
            cols = st.columns(4)
            for i, (label, value) in enumerate(metrics):
                with cols[i % 4]:
                    st.markdown(f'<div class="metric-card"><b>{label}</b><br><span style="font-size:1.6rem;color:{PRIMARY}">{value}</span>/100</div>', unsafe_allow_html=True)
                    st.write("")

        elif page == "Keyword Analysis":
            st.title("🔑 Keyword Analysis")
            kw = score.get("keyword_comparison") or {}
            if not st.session_state.job_description.strip():
                st.info("Add a job description on the **Job Description** page for keyword matching.")
            c1, c2, c3 = st.columns(3)
            with c1:
                st.markdown("#### ✅ Matched")
                for k in kw.get("matched", []):
                    st.markdown(f'<span class="badge badge-match">{k}</span>', unsafe_allow_html=True)
                if not kw.get("matched"):
                    st.caption("None")
            with c2:
                st.markdown("#### ❌ Missing")
                for k in kw.get("missing", []):
                    st.markdown(f'<span class="badge badge-missing">{k}</span>', unsafe_allow_html=True)
                if not kw.get("missing"):
                    st.caption("None")
            with c3:
                st.markdown("#### ➕ Additional")
                for k in kw.get("additional", []):
                    st.markdown(f'<span class="badge badge-partial">{k}</span>', unsafe_allow_html=True)
                if not kw.get("additional"):
                    st.caption("None")

        elif page == "AI Recommendations":
            st.title("🤖 AI Recommendations")
            if result.ai_error:
                st.error(result.ai_error)
            ai = result.ai_analysis
            if not ai:
                st.warning("AI analysis was not run or is unavailable. Enable it in the sidebar and ensure ANTHROPIC_API_KEY is set.")
            else:
                st.markdown("#### AI-Generated Professional Summary")
                st.info(ai.get("summary", ""))

                c1, c2 = st.columns(2)
                with c1:
                    st.markdown("#### Strengths")
                    for s in ai.get("strengths", []):
                        st.markdown(f"- {s}")
                with c2:
                    st.markdown("#### Weaknesses")
                    for w in ai.get("weaknesses", []):
                        st.markdown(f"- {w}")

                st.divider()
                st.markdown("#### Section Recommendations")
                for rec in ai.get("recommendations", []):
                    if isinstance(rec, dict):
                        with st.expander(rec.get("section", "Recommendation")):
                            st.write(rec.get("suggestion", ""))
                    else:
                        st.markdown(f"- {rec}")

                st.divider()
                st.markdown("#### Bullet Point Improvements")
                for b in ai.get("bullet_improvements", []):
                    if not isinstance(b, dict):
                        continue
                    with st.expander(b.get("original", "Bullet")[:80]):
                        st.markdown(f"**Original:** {b.get('original', '')}")
                        st.markdown(f"**Problem:** {b.get('problem', '')}")
                        st.markdown(f"**Improved:** {b.get('improved', '')}")
                        st.markdown(f"**Reason:** {b.get('reason', '')}")

        elif page == "Job Match":
            st.title("🧩 Job Match")
            if not result.match_summary:
                st.info("Add a job description on the **Job Description** page to see job match analysis.")
            else:
                ms = result.match_summary
                st.markdown(
                    f'<div class="score-card"><h1>{ms["job_match_percentage"]}%</h1>'
                    f'<p>Job Match</p></div>', unsafe_allow_html=True,
                )
                st.write("")
                c1, c2, c3 = st.columns(3)
                c1.metric("Strong Matches", len(ms["strong_matches"]))
                c2.metric("Partial Matches", len(ms["partial_matches"]))
                c3.metric("Missing Requirements", len(ms["missing_requirements"]))

                st.divider()
                st.markdown("#### Requirement Match Table")
                rows = result.match_rows or []
                if rows:
                    df = pd.DataFrame(rows).rename(
                        columns={"requirement": "Requirement", "evidence": "Resume Evidence", "status": "Match"}
                    )
                    st.dataframe(df, use_container_width=True, hide_index=True)
                else:
                    st.caption("No specific requirements were detected in the job description.")

        elif page == "Download Report":
            st.title("⬇️ Download Report")
            report_text = generate_report(result, st.session_state.job_description)
            st.text_area("Report preview", report_text, height=400)
            st.download_button(
                "Download Report (Markdown)",
                data=report_text,
                file_name=f"resume_analysis_{resume.name or 'report'}.md".replace(" ", "_"),
                mime="text/markdown",
            )
