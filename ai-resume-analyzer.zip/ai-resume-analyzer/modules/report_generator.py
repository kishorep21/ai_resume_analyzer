"""Generates a downloadable Markdown/plain-text analysis report."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from .resume_analyzer import FullAnalysisResult


def _bullet_list(items, empty_msg="None found.") -> str:
    if not items:
        return f"- {empty_msg}\n"
    return "".join(f"- {item}\n" for item in items)


def generate_report(result: FullAnalysisResult, job_description: str = "") -> str:
    """Build a full Markdown analysis report from a :class:`FullAnalysisResult`.

    Args:
        result: The completed analysis result.
        job_description: The job description used, if any (for the header).

    Returns:
        A Markdown-formatted report string, suitable for download as .md or
        conversion to PDF/DOCX.
    """
    resume = result.parsed_resume
    score = result.score_breakdown
    strengths = result.strength_analysis
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    lines = []
    lines.append("# AI Resume Analysis Report")
    lines.append(f"_Generated: {generated_at}_\n")

    lines.append("## 1. Resume Overview")
    lines.append(f"- **Name:** {resume.name or 'Not detected'}")
    lines.append(f"- **Email:** {resume.email or 'Not detected'}")
    lines.append(f"- **Phone:** {resume.phone or 'Not detected'}")
    lines.append(f"- **Location:** {resume.location or 'Not detected'}")
    lines.append(f"- **LinkedIn:** {resume.linkedin or 'Not detected'}")
    lines.append(f"- **GitHub:** {resume.github or 'Not detected'}")
    lines.append(f"- **Skills listed:** {len(resume.skills)}")
    lines.append(f"- **Experience entries:** {len(resume.experience)}")
    lines.append(f"- **Projects:** {len(resume.projects)}\n")

    lines.append("## 2. ATS Score")
    lines.append(f"**Overall ATS Score: {score['overall_score']}/100**\n")
    lines.append("| Component | Score |")
    lines.append("|---|---|")
    lines.append(f"| Keyword Match | {score['keyword_score']}/100 |")
    lines.append(f"| Skills Match | {score['skills_score']}/100 |")
    lines.append(f"| Experience Relevance | {score['experience_score']}/100 |")
    lines.append(f"| Project Relevance | {score['project_score']}/100 |")
    lines.append(f"| Resume Structure | {score['structure_score']}/100 |")
    lines.append(f"| Education/Certification | {score['education_score']}/100 |")
    lines.append(f"| Formatting/ATS Compatibility | {score['formatting_score']}/100 |")
    lines.append(f"| Contact Information | {score['contact_score']}/100 |\n")

    kw = score.get("keyword_comparison") or {}
    lines.append("## 3. Keyword Analysis")
    lines.append("**Matched Keywords:**")
    lines.append(_bullet_list(kw.get("matched"), "No job description provided or no matches found."))
    lines.append("**Missing Keywords:**")
    lines.append(_bullet_list(kw.get("missing"), "None found."))
    lines.append("**Additional Relevant Keywords:**")
    lines.append(_bullet_list(kw.get("additional"), "None found.") + "\n")

    lines.append("## 4. Resume Strength Analysis")
    lines.append(f"**Strong sections:** {', '.join(strengths.strong_sections) or 'None'}")
    lines.append(f"**Weak sections:** {', '.join(strengths.weak_sections) or 'None'}")
    lines.append(f"**Missing sections:** {', '.join(strengths.missing_sections) or 'None'}\n")
    lines.append("**Generic statements found:**")
    lines.append(_bullet_list(strengths.generic_statements))
    lines.append("**Overused words:**")
    lines.append(_bullet_list(strengths.repeated_words))
    lines.append("**Weak action-verb bullets:**")
    lines.append(_bullet_list(strengths.weak_action_verbs))
    lines.append("**Quantification opportunities:**")
    lines.append(_bullet_list(strengths.quantification_opportunities))
    lines.append("**Formatting problems:**")
    lines.append(_bullet_list(strengths.formatting_problems))
    lines.append("**ATS-unfriendly elements:**")
    lines.append(_bullet_list(strengths.ats_unfriendly_elements) + "\n")

    if result.ai_analysis:
        ai = result.ai_analysis
        lines.append("## 5. AI Recommendations")
        lines.append(f"**AI-Generated Summary:**\n\n> {ai.get('summary', '').strip()}\n")
        lines.append("**Strengths (AI):**")
        lines.append(_bullet_list(ai.get("strengths")))
        lines.append("**Weaknesses (AI):**")
        lines.append(_bullet_list(ai.get("weaknesses")))
        recs = ai.get("recommendations") or []
        if recs:
            lines.append("**Recommendations:**")
            for r in recs:
                if isinstance(r, dict):
                    lines.append(f"- **{r.get('section', 'General')}:** {r.get('suggestion', '')}")
                else:
                    lines.append(f"- {r}")
            lines.append("")
        bullets = ai.get("bullet_improvements") or []
        if bullets:
            lines.append("**Bullet Point Improvements:**\n")
            for b in bullets:
                if not isinstance(b, dict):
                    continue
                lines.append(f"- Original: \"{b.get('original', '')}\"")
                lines.append(f"  - Problem: {b.get('problem', '')}")
                lines.append(f"  - Improved: \"{b.get('improved', '')}\"")
                lines.append(f"  - Reason: {b.get('reason', '')}\n")
    elif result.ai_error:
        lines.append("## 5. AI Recommendations")
        lines.append(f"_AI analysis unavailable: {result.ai_error}_\n")

    if result.match_summary:
        lines.append("## 6. Job Match Analysis")
        lines.append(f"**Job Match: {result.match_summary['job_match_percentage']}%**\n")
        lines.append("**Strong matches:** " + (", ".join(result.match_summary["strong_matches"]) or "None"))
        lines.append("**Partial matches:** " + (", ".join(result.match_summary["partial_matches"]) or "None"))
        lines.append("**Missing requirements:** " + (", ".join(result.match_summary["missing_requirements"]) or "None") + "\n")
        lines.append("| Requirement | Resume Evidence | Match |")
        lines.append("|---|---|---|")
        for row in result.match_rows or []:
            evidence = row["evidence"].replace("|", "\\|")
            lines.append(f"| {row['requirement']} | {evidence} | {row['status']} |")
        lines.append("")

    lines.append("---")
    lines.append("_Report generated by AI Resume Analyzer & ATS Score Generator._")

    return "\n".join(lines)


def save_report_to_file(report_text: str, path: str) -> str:
    """Write a report string to disk.

    Args:
        report_text: The Markdown report content.
        path: Destination file path.

    Returns:
        The path written to.
    """
    with open(path, "w", encoding="utf-8") as f:
        f.write(report_text)
    return path
