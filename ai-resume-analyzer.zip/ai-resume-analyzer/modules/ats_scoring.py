"""Deterministic ATS scoring.

The overall score is a transparent weighted sum of sub-scores. Nothing here
is randomly generated -- every component is derived from the resume text and
(optionally) the job description.

Weights:
    Keyword Match:                 30%
    Skills Match:                  20%
    Experience Relevance:          15%
    Project Relevance:             10%
    Resume Structure:              10%
    Education/Certification:        5%
    Formatting/ATS Compatibility:   5%
    Contact Information:            5%
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from typing import Optional

from .keyword_analyzer import KeywordComparison, compare_keywords, extract_job_requirements
from .resume_parser import ParsedResume

WEIGHTS = {
    "keyword_score": 0.30,
    "skills_score": 0.20,
    "experience_score": 0.15,
    "project_score": 0.10,
    "structure_score": 0.10,
    "education_score": 0.05,
    "formatting_score": 0.05,
    "contact_score": 0.05,
}

REQUIRED_SECTIONS = ["summary", "skills", "experience", "education"]
WEAK_FORMATTING_PATTERNS = [
    re.compile(r"\t{2,}"),          # excessive tabs (table artifacts)
    re.compile(r"[|]{2,}"),          # leftover table pipes
    re.compile(r"\uf0b7|\uf0a7"),    # private-use bullet glyphs (bad PDF extraction)
]


@dataclass
class ScoreBreakdown:
    """Structured ATS score result."""

    overall_score: int
    keyword_score: int
    skills_score: int
    experience_score: int
    project_score: int
    structure_score: int
    education_score: int
    formatting_score: int
    contact_score: int
    keyword_comparison: Optional[KeywordComparison] = None

    def to_dict(self) -> dict:
        data = asdict(self)
        if self.keyword_comparison is not None:
            data["keyword_comparison"] = {
                "matched": self.keyword_comparison.matched,
                "missing": self.keyword_comparison.missing,
                "additional": self.keyword_comparison.additional,
                "match_ratio": round(self.keyword_comparison.match_ratio, 3),
            }
        return data


def _score_structure(resume: ParsedResume) -> int:
    """Score resume structure based on presence of expected sections."""
    present = 0
    if resume.summary:
        present += 1
    if resume.skills:
        present += 1
    if resume.experience or resume.internships:
        present += 1
    if resume.education:
        present += 1
    return round((present / len(REQUIRED_SECTIONS)) * 100)


def _score_formatting(raw_text: str) -> int:
    """Penalize ATS-unfriendly formatting artifacts found in extracted text."""
    score = 100
    for pattern in WEAK_FORMATTING_PATTERNS:
        if pattern.search(raw_text):
            score -= 15
    # Very short lines everywhere can indicate a multi-column layout that
    # confuses ATS parsers.
    lines = [l for l in raw_text.split("\n") if l.strip()]
    if lines:
        short_lines = sum(1 for l in lines if len(l.strip()) < 15)
        if short_lines / len(lines) > 0.6:
            score -= 20
    return max(score, 0)


def _score_contact(resume: ParsedResume) -> int:
    return round(resume.contact_completeness() * 100)


def _score_education(resume: ParsedResume, requirements) -> int:
    if not resume.education and not resume.certifications:
        return 0
    if not requirements or not requirements.education_requirements:
        # No JD requirement to compare against -- score on presence alone.
        return 100 if (resume.education or resume.certifications) else 0

    edu_text = " ".join(resume.education + resume.certifications).lower()
    req_text = " ".join(requirements.education_requirements).lower()
    keywords = re.findall(r"[a-z]+", req_text)
    if not keywords:
        return 100 if resume.education else 50
    hits = sum(1 for k in set(keywords) if k in edu_text)
    return round(min(hits / max(len(set(keywords)), 1), 1.0) * 100)


def _score_experience(resume: ParsedResume, jd_keywords: set) -> int:
    entries = resume.experience + resume.internships
    if not entries:
        return 0
    if not jd_keywords:
        # No JD provided: score on presence + light quality heuristic
        # (quantified bullets, action verbs).
        text = " ".join(entries).lower()
        has_numbers = bool(re.search(r"\d", text))
        return 80 + (20 if has_numbers else 0)

    text = " ".join(entries).lower()
    hits = sum(1 for kw in jd_keywords if kw in text)
    return round(min(hits / max(len(jd_keywords), 1) * 1.5, 1.0) * 100)


def _score_projects(resume: ParsedResume, jd_keywords: set) -> int:
    if not resume.projects:
        return 0
    if not jd_keywords:
        return 75
    text = " ".join(resume.projects).lower()
    hits = sum(1 for kw in jd_keywords if kw in text)
    return round(min(hits / max(len(jd_keywords), 1) * 1.5, 1.0) * 100)


def _score_skills(comparison: KeywordComparison, resume: ParsedResume) -> int:
    if comparison.matched or comparison.missing:
        return round(comparison.match_ratio * 100)
    # No JD given -- score on breadth of listed skills as a proxy.
    return min(len(resume.skills) * 8, 100)


def calculate_ats_score(resume_text: str, job_description: str = "") -> dict:
    """Calculate a transparent, weighted ATS score for a resume.

    This performs its own resume parsing internally so it can be called with
    just raw text (per the required signature), but for best results the
    caller may have already parsed the resume elsewhere in the app -- the
    parsing here is cheap and deterministic so re-running it is safe.

    Args:
        resume_text: Full plain-text content of the resume.
        job_description: Optional job description text. If empty, scoring
            falls back to presence/quality heuristics that don't depend on a
            job description.

    Returns:
        A dict with the following integer (0-100) keys: ``overall_score``,
        ``keyword_score``, ``skills_score``, ``experience_score``,
        ``project_score``, ``formatting_score``, ``structure_score``,
        ``education_score``, ``contact_score``. Also includes
        ``keyword_comparison`` with matched/missing/additional keyword lists.

    Raises:
        ValueError: If ``resume_text`` is empty or whitespace-only.
    """
    if not resume_text or not resume_text.strip():
        raise ValueError("Resume text is empty. Please provide a valid resume.")

    # Build a lightweight ParsedResume from raw text so this function is
    # usable standalone (e.g. from tests) without going through the parser
    # module's file-extraction path.
    resume = _parsed_resume_from_text(resume_text)

    requirements = extract_job_requirements(job_description) if job_description else None
    comparison = (
        compare_keywords(resume_text, requirements)
        if requirements is not None
        else KeywordComparison()
    )
    jd_keywords = requirements.all_keywords() if requirements else set()

    keyword_score = round(comparison.match_ratio * 100) if requirements else 0
    skills_score = _score_skills(comparison, resume)
    experience_score = _score_experience(resume, jd_keywords)
    project_score = _score_projects(resume, jd_keywords)
    structure_score = _score_structure(resume)
    education_score = _score_education(resume, requirements)
    formatting_score = _score_formatting(resume_text)
    contact_score = _score_contact(resume)

    component_scores = {
        "keyword_score": keyword_score,
        "skills_score": skills_score,
        "experience_score": experience_score,
        "project_score": project_score,
        "structure_score": structure_score,
        "education_score": education_score,
        "formatting_score": formatting_score,
        "contact_score": contact_score,
    }

    if not job_description or not job_description.strip():
        # Redistribute the keyword-match weight across skills/experience/projects
        # since there's nothing to match keywords against.
        overall = (
            component_scores["skills_score"] * 0.35
            + component_scores["experience_score"] * 0.25
            + component_scores["project_score"] * 0.15
            + component_scores["structure_score"] * 0.10
            + component_scores["education_score"] * 0.05
            + component_scores["formatting_score"] * 0.05
            + component_scores["contact_score"] * 0.05
        )
    else:
        overall = sum(component_scores[k] * WEIGHTS[k] for k in WEIGHTS)

    breakdown = ScoreBreakdown(
        overall_score=round(overall),
        keyword_score=keyword_score,
        skills_score=skills_score,
        experience_score=experience_score,
        project_score=project_score,
        structure_score=structure_score,
        education_score=education_score,
        formatting_score=formatting_score,
        contact_score=contact_score,
        keyword_comparison=comparison,
    )
    return breakdown.to_dict()


def _parsed_resume_from_text(resume_text: str) -> ParsedResume:
    """Build a ParsedResume from already-extracted plain text (no file I/O)."""
    from .resume_parser import parse_contact_info, split_into_sections, _split_entries, _extract_skills

    contact = parse_contact_info(resume_text)
    sections = split_into_sections(resume_text)
    return ParsedResume(
        raw_text=resume_text,
        name=contact["name"],
        email=contact["email"],
        phone=contact["phone"],
        location=contact["location"],
        linkedin=contact["linkedin"],
        github=contact["github"],
        summary=" ".join(sections["summary"]).strip() or None,
        education=_split_entries(sections["education"]),
        skills=_extract_skills(sections["skills"]),
        experience=_split_entries(sections["experience"]),
        internships=_split_entries(sections["internships"]),
        projects=_split_entries(sections["projects"]),
        certifications=_split_entries(sections["certifications"]),
        achievements=_split_entries(sections["achievements"]),
    )
