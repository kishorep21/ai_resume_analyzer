"""Shared utility helpers: config loading, validation, and text sanitization."""

from __future__ import annotations

import os
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Optional

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------

ALLOWED_EXTENSIONS = {".pdf", ".docx"}
MAX_FILE_SIZE_MB = 5
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024


@dataclass
class AppConfig:
    """Runtime configuration loaded from environment variables."""

    anthropic_api_key: Optional[str] = field(default=None)
    claude_model: str = "claude-sonnet-4-6"
    max_file_size_mb: int = MAX_FILE_SIZE_MB
    db_path: str = "data/analysis_history.db"

    @classmethod
    def load(cls) -> "AppConfig":
        """Load configuration from environment variables (.env is loaded by app.py)."""
        return cls(
            anthropic_api_key=os.environ.get("ANTHROPIC_API_KEY"),
            claude_model=os.environ.get("CLAUDE_MODEL", "claude-sonnet-4-6"),
            max_file_size_mb=int(os.environ.get("MAX_FILE_SIZE_MB", MAX_FILE_SIZE_MB)),
            db_path=os.environ.get("DB_PATH", "data/analysis_history.db"),
        )


# --------------------------------------------------------------------------
# Custom exceptions
# --------------------------------------------------------------------------


class FileValidationError(Exception):
    """Raised when an uploaded file fails validation."""


class ExtractionError(Exception):
    """Raised when text cannot be extracted from a document."""


class ClaudeAPIError(Exception):
    """Raised when the Claude API call fails or returns an unusable response."""


# --------------------------------------------------------------------------
# File validation
# --------------------------------------------------------------------------


def validate_file(filename: str, size_bytes: int, max_size_mb: int = MAX_FILE_SIZE_MB) -> None:
    """Validate an uploaded file's extension and size.

    Args:
        filename: The original filename, including extension.
        size_bytes: Size of the uploaded file in bytes.
        max_size_mb: Maximum allowed file size in megabytes.

    Raises:
        FileValidationError: If the extension is unsupported or the file is too large
            or empty.
    """
    if not filename:
        raise FileValidationError("Please upload a PDF or DOCX resume.")

    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise FileValidationError("Please upload a PDF or DOCX resume.")

    if size_bytes <= 0:
        raise FileValidationError("The uploaded file appears to be empty.")

    max_bytes = max_size_mb * 1024 * 1024
    if size_bytes > max_bytes:
        raise FileValidationError(
            f"File is too large. Please upload a resume smaller than {max_size_mb}MB."
        )


# --------------------------------------------------------------------------
# Text sanitization
# --------------------------------------------------------------------------


def sanitize_text(text: str) -> str:
    """Normalize and clean extracted text for downstream processing.

    Removes control characters, normalizes unicode/whitespace, and strips
    characters that are not useful for NLP or display.

    Args:
        text: Raw extracted text.

    Returns:
        A cleaned, normalized string. Returns an empty string for falsy input.
    """
    if not text:
        return ""

    text = unicodedata.normalize("NFKC", text)
    # Strip control characters except newlines/tabs.
    text = "".join(ch for ch in text if ch == "\n" or ch == "\t" or not unicodedata.category(ch).startswith("C"))
    # Collapse excessive whitespace but keep paragraph breaks.
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def normalize_token(token: str) -> str:
    """Lowercase and strip a keyword/skill token for comparison purposes."""
    return re.sub(r"[^a-z0-9+#./ ]", "", token.lower()).strip()


def truncate(text: str, max_chars: int = 12000) -> str:
    """Truncate text to a maximum character length, preserving whole words."""
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rsplit(" ", 1)[0] + " ..."
