"""Thin wrapper around the Anthropic Claude API for resume analysis.

Keeps all Claude-specific concerns (client construction, prompt templates,
JSON parsing/validation, retries, and error handling) in one place. No API
key is ever hardcoded -- it is always read from the environment.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Optional

from .utils import ClaudeAPIError, truncate

DEFAULT_MODEL = os.environ.get("CLAUDE_MODEL", "claude-sonnet-4-6")

EXPECTED_KEYS = {
    "summary",
    "strengths",
    "weaknesses",
    "missing_keywords",
    "matched_keywords",
    "recommendations",
    "job_match",
    "bullet_improvements",
}

SYSTEM_PROMPT = (
    "You are an expert technical resume reviewer and ATS (Applicant Tracking "
    "System) specialist. You analyze resumes strictly based on the content "
    "provided to you. You NEVER invent experience, employers, technologies, "
    "certifications, achievements, or metrics that are not present in the "
    "resume text given to you. When a job description is provided, ground "
    "your analysis in it; when it is not, give general best-practice "
    "feedback. You always respond with a single valid JSON object and "
    "nothing else -- no markdown fences, no preamble, no commentary outside "
    "the JSON."
)

RESPONSE_SCHEMA_INSTRUCTIONS = """
Respond with ONLY a valid JSON object (no markdown code fences, no extra text)
with exactly this shape:

{
  "summary": "3-5 line professional summary based only on resume content",
  "strengths": ["..."],
  "weaknesses": ["..."],
  "missing_keywords": ["..."],
  "matched_keywords": ["..."],
  "recommendations": [
    {"section": "Professional Summary", "suggestion": "..."},
    {"section": "Skills", "suggestion": "..."},
    {"section": "Work Experience", "suggestion": "..."},
    {"section": "Projects", "suggestion": "..."},
    {"section": "Certifications", "suggestion": "..."},
    {"section": "Achievements", "suggestion": "..."},
    {"section": "Keywords", "suggestion": "..."}
  ],
  "job_match": [
    {"requirement": "...", "evidence": "...", "status": "Match|Partial|Missing"}
  ],
  "bullet_improvements": [
    {"original": "...", "problem": "...", "improved": "...", "reason": "..."}
  ]
}

Rules:
- Do not invent any company, technology, certification, achievement, or metric
  that is not present in the resume text.
- Only include bullet_improvements for bullets that genuinely exist in the resume.
- If no job description was provided, return an empty list for "job_match" and
  "missing_keywords", and focus "recommendations" on general resume quality.
- Keep the JSON valid and parseable -- use double quotes, no trailing commas.
"""


def _get_client():
    """Lazily construct the Anthropic client, raising a friendly error if the
    SDK isn't installed or no API key is configured."""
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise ClaudeAPIError(
            "Claude API is currently unavailable. No ANTHROPIC_API_KEY was found "
            "in the environment. Please set it in your .env file."
        )
    try:
        import anthropic
    except ImportError as exc:
        raise ClaudeAPIError(
            "Claude API is currently unavailable. The 'anthropic' package is not "
            "installed. Run: pip install anthropic"
        ) from exc

    try:
        return anthropic.Anthropic(api_key=api_key)
    except Exception as exc:  # noqa: BLE001
        raise ClaudeAPIError(f"Claude API is currently unavailable: {exc}") from exc


def _extract_json(raw_text: str) -> dict:
    """Extract and parse a JSON object from a Claude text response.

    Strips markdown code fences if present and finds the outermost JSON
    object if there is surrounding commentary.
    """
    text = raw_text.strip()
    text = re.sub(r"^```(json)?", "", text.strip(), flags=re.IGNORECASE).strip()
    text = re.sub(r"```$", "", text.strip()).strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Fall back to locating the first {...} block.
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        candidate = text[start : end + 1]
        try:
            return json.loads(candidate)
        except json.JSONDecodeError as exc:
            raise ClaudeAPIError(
                "Claude returned a response that could not be parsed as JSON."
            ) from exc

    raise ClaudeAPIError("Claude returned a response that could not be parsed as JSON.")


def validate_analysis_response(data: dict) -> dict:
    """Validate the structure of Claude's parsed JSON response.

    Ensures all expected top-level keys exist (filling in safe defaults for
    any that are missing) so downstream code can rely on a consistent shape.

    Args:
        data: Parsed JSON dict from Claude.

    Returns:
        The same dict, normalized with all expected keys present.

    Raises:
        ClaudeAPIError: If ``data`` is not a dict at all.
    """
    if not isinstance(data, dict):
        raise ClaudeAPIError("Claude returned an unexpected response format.")

    normalized = dict(data)
    defaults = {
        "summary": "",
        "strengths": [],
        "weaknesses": [],
        "missing_keywords": [],
        "matched_keywords": [],
        "recommendations": [],
        "job_match": [],
        "bullet_improvements": [],
    }
    for key, default in defaults.items():
        if key not in normalized or normalized[key] is None:
            normalized[key] = default
    return normalized


def _build_user_prompt(
    resume_text: str,
    job_description: str,
    parsed_fields: Optional[dict],
    keyword_comparison: Optional[dict],
    target_role: Optional[str],
) -> str:
    """Assemble the structured prompt sent to Claude.

    Rather than dumping the entire application state, only the fields Claude
    actually needs for semantic analysis are included.
    """
    parts = [
        "Analyze the following resume." + (f" The candidate is targeting the role: {target_role}." if target_role else ""),
        "\n--- RESUME TEXT ---\n" + truncate(resume_text, 9000),
    ]
    if parsed_fields:
        parts.append("\n--- EXTRACTED FIELDS (for reference only) ---\n" + json.dumps(parsed_fields, indent=2)[:3000])
    if job_description and job_description.strip():
        parts.append("\n--- JOB DESCRIPTION ---\n" + truncate(job_description, 4000))
    else:
        parts.append("\n--- JOB DESCRIPTION ---\nNone provided. Give general best-practice feedback.")
    if keyword_comparison:
        parts.append(
            "\n--- DETERMINISTIC KEYWORD MATCH (already computed in Python, "
            "for reference/consistency) ---\n" + json.dumps(keyword_comparison, indent=2)
        )
    parts.append("\n" + RESPONSE_SCHEMA_INSTRUCTIONS)
    return "\n".join(parts)


def analyze_resume_with_claude(
    resume_text: str,
    job_description: str = "",
    parsed_fields: Optional[dict] = None,
    keyword_comparison: Optional[dict] = None,
    target_role: Optional[str] = None,
    model: Optional[str] = None,
    max_retries: int = 2,
) -> dict:
    """Send resume (and optional job description) to Claude for semantic analysis.

    Args:
        resume_text: Full extracted resume text.
        job_description: Optional job description text.
        parsed_fields: Optional dict of already-extracted structured fields
            (name, skills, etc.) to give Claude context without re-sending
            the whole app state.
        keyword_comparison: Optional dict with matched/missing/additional
            keywords computed deterministically in Python, passed along so
            Claude's narrative stays consistent with the numbers shown.
        target_role: Optional target role for the generated summary.
        model: Override the Claude model name.
        max_retries: Number of times to retry on a malformed JSON response.

    Returns:
        A validated dict matching the documented response schema.

    Raises:
        ClaudeAPIError: If the API call fails or a usable response can't be
            obtained after retries.
    """
    if not resume_text or not resume_text.strip():
        raise ClaudeAPIError("Please provide resume text before requesting AI analysis.")

    client = _get_client()
    prompt = _build_user_prompt(resume_text, job_description, parsed_fields, keyword_comparison, target_role)
    model_name = model or DEFAULT_MODEL

    last_error: Optional[Exception] = None
    for attempt in range(max_retries + 1):
        try:
            response = client.messages.create(
                model=model_name,
                max_tokens=4000,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
            )
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            continue

        try:
            text_blocks = [block.text for block in response.content if getattr(block, "type", None) == "text"]
            raw_text = "\n".join(text_blocks)
            parsed = _extract_json(raw_text)
            return validate_analysis_response(parsed)
        except ClaudeAPIError as exc:
            last_error = exc
            continue

    raise ClaudeAPIError(
        f"Claude API is currently unavailable. {last_error}" if last_error else
        "Claude API is currently unavailable."
    )


def generate_resume_summary(
    resume_text: str,
    target_role: Optional[str] = None,
    model: Optional[str] = None,
) -> str:
    """Generate a focused 3-5 line professional summary using only resume content.

    Args:
        resume_text: Full extracted resume text.
        target_role: Optional target role to tailor tone/emphasis (content
            must still only draw on what's in the resume).
        model: Override the Claude model name.

    Returns:
        The generated summary text.

    Raises:
        ClaudeAPIError: On API failure or an empty response.
    """
    if not resume_text or not resume_text.strip():
        raise ClaudeAPIError("Please provide resume text before generating a summary.")

    client = _get_client()
    role_line = f" tailored for a {target_role} role" if target_role else ""
    prompt = (
        f"Write a professional 3-5 line resume summary{role_line}, based ONLY on the "
        "information present in the resume text below. Do not invent any experience, "
        "skills, employers, or metrics that are not present. Return ONLY the summary "
        "text, with no preamble, labels, or quotation marks.\n\n--- RESUME TEXT ---\n"
        + truncate(resume_text, 9000)
    )

    try:
        response = client.messages.create(
            model=model or DEFAULT_MODEL,
            max_tokens=400,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )
    except Exception as exc:  # noqa: BLE001
        raise ClaudeAPIError(f"Claude API is currently unavailable: {exc}") from exc

    text_blocks = [block.text for block in response.content if getattr(block, "type", None) == "text"]
    summary = "\n".join(text_blocks).strip()
    if not summary:
        raise ClaudeAPIError("Claude API returned an empty summary.")
    return summary
