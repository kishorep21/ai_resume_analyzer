"""Builds a requirement-by-requirement job match table.

Every row is backed by literal evidence found in the resume text -- nothing
is asserted about the candidate that can't be pointed to in the source
document.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional

from .keyword_analyzer import JobRequirements
from .utils import normalize_token


@dataclass
class MatchRow:
    """One row of the job-match table."""

    requirement: str
    evidence: str
    status: str  # "Match" | "Partial" | "Missing"


def _find_evidence(keyword: str, resume_text: str, resume_sections: dict) -> Optional[str]:
    """Find a short snippet of resume text that mentions the keyword."""
    pattern = re.compile(r"(?<![a-z0-9])" + re.escape(keyword.lower()) + r"(?![a-z0-9])")
    lower = resume_text.lower()
    match = pattern.search(lower)
    if not match:
        return None

    start = max(match.start() - 40, 0)
    end = min(match.end() + 40, len(resume_text))
    snippet = resume_text[start:end].strip()
    snippet = re.sub(r"\s+", " ", snippet)
    if start > 0:
        snippet = "..." + snippet
    if end < len(resume_text):
        snippet = snippet + "..."
    return snippet


def build_job_match_table(resume_text: str, requirements: JobRequirements) -> List[MatchRow]:
    """Build the requirement -> evidence -> match-status table.

    Args:
        resume_text: Full extracted resume text.
        requirements: Parsed job requirements.

    Returns:
        A list of :class:`MatchRow`, one per required/preferred skill or
        keyword found in the job description. Rows are sorted with matches
        first, then partial, then missing.
    """
    all_reqs = list(dict.fromkeys(
        requirements.required_skills
        + requirements.preferred_skills
        + requirements.tools_technologies
    ))

    rows: List[MatchRow] = []
    for req in all_reqs:
        evidence = _find_evidence(req, resume_text, {})
        if evidence:
            rows.append(MatchRow(requirement=req, evidence=evidence, status="Match"))
        else:
            # Check for a partial / related match (e.g. "AWS Lambda" mentioned
            # when JD asked for "aws").
            related = None
            for token in normalize_token(req).split():
                if len(token) > 2:
                    ev = _find_evidence(token, resume_text, {})
                    if ev:
                        related = ev
                        break
            if related:
                rows.append(MatchRow(requirement=req, evidence=related, status="Partial"))
            else:
                rows.append(MatchRow(requirement=req, evidence="Not found", status="Missing"))

    status_order = {"Match": 0, "Partial": 1, "Missing": 2}
    rows.sort(key=lambda r: status_order[r.status])
    return rows


def summarize_match(rows: List[MatchRow]) -> dict:
    """Summarize match rows into strong/partial/missing buckets and a percentage."""
    strong = [r.requirement for r in rows if r.status == "Match"]
    partial = [r.requirement for r in rows if r.status == "Partial"]
    missing = [r.requirement for r in rows if r.status == "Missing"]
    total = len(rows) or 1
    match_percentage = round(((len(strong) + 0.5 * len(partial)) / total) * 100)
    return {
        "strong_matches": strong,
        "partial_matches": partial,
        "missing_requirements": missing,
        "job_match_percentage": match_percentage,
    }
