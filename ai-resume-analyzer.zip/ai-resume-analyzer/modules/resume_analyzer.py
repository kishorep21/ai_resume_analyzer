"""Deterministic resume strength/weakness analysis, plus the orchestration
function that ties parsing, scoring, keyword analysis, job matching, and the
Claude call together into a single analysis result for the app.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from typing import List, Optional

from . import claude_client
from .ats_scoring import calculate_ats_score
from .job_matcher import build_job_match_table, summarize_match
from .keyword_analyzer import compare_keywords, extract_job_requirements
from .resume_parser import ParsedResume, parse_resume
from .utils import ClaudeAPIError

WEAK_VERBS = {
    "responsible for", "worked on", "helped with", "involved in", "assisted with",
    "did", "handled", "was part of", "tasked with", "duties included",
}

STRONG_ACTION_VERBS = {
    "led", "built", "designed", "implemented", "architected", "optimized",
    "developed", "launched", "automated", "reduced", "increased", "improved",
    "delivered", "created", "engineered", "deployed", "migrated", "streamlined",
}

GENERIC_PHRASES = {
    "hard working", "hardworking", "team player", "detail oriented",
    "detail-oriented", "fast learner", "go-getter", "self motivated",
    "self-motivated", "results driven", "results-driven", "think outside the box",
    "passionate about", "dynamic professional",
}

REQUIRED_SECTIONS = ["summary", "skills", "experience", "education", "projects"]


@dataclass
class StrengthAnalysis:
    """Deterministic (non-AI) strength/weakness findings."""

    strong_sections: List[str] = field(default_factory=list)
    weak_sections: List[str] = field(default_factory=list)
    missing_sections: List[str] = field(default_factory=list)
    generic_statements: List[str] = field(default_factory=list)
    repeated_words: List[str] = field(default_factory=list)
    weak_action_verbs: List[str] = field(default_factory=list)
    quantification_opportunities: List[str] = field(default_factory=list)
    formatting_problems: List[str] = field(default_factory=list)
    ats_unfriendly_elements: List[str] = field(default_factory=list)


def _find_generic_statements(text: str) -> List[str]:
    lower = text.lower()
    found = []
    for phrase in GENERIC_PHRASES:
        if phrase in lower:
            found.append(phrase)
    return found


def _find_repeated_words(text: str, min_count: int = 5) -> List[str]:
    words = re.findall(r"[a-zA-Z]{4,}", text.lower())
    stop = {"with", "have", "that", "this", "from", "were", "which", "their", "using"}
    counts = Counter(w for w in words if w not in stop)
    return [w for w, c in counts.most_common(15) if c >= min_count]


def _find_weak_verb_bullets(entries: List[str]) -> List[str]:
    found = []
    for entry in entries:
        lower = entry.lower()
        for verb in WEAK_VERBS:
            if lower.startswith(verb) or f" {verb}" in lower[:60]:
                found.append(entry)
                break
    return found


def _find_quantification_opportunities(entries: List[str]) -> List[str]:
    """Bullets describing impact/results but with no numbers -- good candidates
    for adding metrics."""
    impact_words = {"improved", "increased", "reduced", "optimized", "grew",
                     "saved", "accelerated", "scaled", "decreased", "boosted"}
    opportunities = []
    for entry in entries:
        lower = entry.lower()
        has_number = bool(re.search(r"\d", entry))
        has_impact_word = any(w in lower for w in impact_words)
        if has_impact_word and not has_number:
            opportunities.append(entry)
    return opportunities


def _find_formatting_problems(raw_text: str) -> List[str]:
    problems = []
    if re.search(r"\t{2,}", raw_text):
        problems.append("Detected multi-column/tab-based layout that may confuse ATS parsers.")
    if re.search(r"\uf0b7|\uf0a7", raw_text):
        problems.append("Detected special bullet glyphs that may not render correctly in ATS systems.")
    if len(raw_text) < 500:
        problems.append("Resume content seems unusually short.")
    if re.search(r"(?i)page \d+ of \d+", raw_text):
        problems.append("Page numbers detected in body text -- consider removing for ATS parsing.")
    return problems


def _find_ats_unfriendly_elements(raw_text: str) -> List[str]:
    elements = []
    if re.search(r"(?i)\btable\b", raw_text) and raw_text.count("\t") > 10:
        elements.append("Possible use of tables, which some ATS systems parse poorly.")
    if re.search(r"[^\x00-\x7F]{3,}", raw_text):
        elements.append("Non-standard characters detected -- verify they render correctly after ATS parsing.")
    return elements


def analyze_resume_strength(resume: ParsedResume) -> StrengthAnalysis:
    """Run deterministic heuristic checks over a parsed resume.

    Args:
        resume: A :class:`ParsedResume`.

    Returns:
        A populated :class:`StrengthAnalysis`.
    """
    strong, weak, missing = [], [], []
    section_map = {
        "summary": resume.summary,
        "skills": resume.skills,
        "experience": resume.experience or resume.internships,
        "education": resume.education,
        "projects": resume.projects,
    }
    for name, value in section_map.items():
        if not value:
            missing.append(name)
        elif isinstance(value, list) and len(value) < 2:
            weak.append(name)
        elif isinstance(value, str) and len(value) < 60:
            weak.append(name)
        else:
            strong.append(name)

    all_entries = resume.experience + resume.internships + resume.projects
    generic = _find_generic_statements(resume.raw_text)
    repeated = _find_repeated_words(resume.raw_text)
    weak_verbs = _find_weak_verb_bullets(all_entries)
    quant_ops = _find_quantification_opportunities(all_entries)
    formatting_problems = _find_formatting_problems(resume.raw_text)
    ats_elements = _find_ats_unfriendly_elements(resume.raw_text)

    return StrengthAnalysis(
        strong_sections=strong,
        weak_sections=weak,
        missing_sections=missing,
        generic_statements=generic,
        repeated_words=repeated,
        weak_action_verbs=weak_verbs,
        quantification_opportunities=quant_ops,
        formatting_problems=formatting_problems,
        ats_unfriendly_elements=ats_elements,
    )


@dataclass
class FullAnalysisResult:
    """Everything the dashboard needs, assembled in one place."""

    parsed_resume: ParsedResume
    score_breakdown: dict
    strength_analysis: StrengthAnalysis
    job_requirements: Optional[dict]
    match_summary: Optional[dict]
    match_rows: Optional[list]
    ai_analysis: Optional[dict]
    ai_error: Optional[str] = None


def run_full_analysis(
    filename: str,
    file_bytes: bytes,
    job_description: str = "",
    target_role: Optional[str] = None,
    use_ai: bool = True,
) -> FullAnalysisResult:
    """Run the complete analysis pipeline: parse -> score -> match -> AI review.

    Args:
        filename: Original resume filename.
        file_bytes: Raw resume file bytes.
        job_description: Optional job description text.
        target_role: Optional target role for the AI-generated summary.
        use_ai: Whether to call Claude for semantic analysis. If False, or if
            the Claude call fails, deterministic results are still returned
            with ``ai_analysis`` set to ``None`` and ``ai_error`` populated.

    Returns:
        A :class:`FullAnalysisResult`.

    Raises:
        ExtractionError: If the resume file can't be parsed.
        ValueError: If extracted resume text is empty.
    """
    resume = parse_resume(filename, file_bytes)
    score = calculate_ats_score(resume.raw_text, job_description)
    strengths = analyze_resume_strength(resume)

    requirements = None
    match_summary = None
    match_rows = None
    if job_description and job_description.strip():
        req_obj = extract_job_requirements(job_description)
        requirements = {
            "required_skills": req_obj.required_skills,
            "preferred_skills": req_obj.preferred_skills,
            "technical_keywords": req_obj.technical_keywords,
            "soft_skills": req_obj.soft_skills,
            "education_requirements": req_obj.education_requirements,
            "experience_requirements": req_obj.experience_requirements,
            "tools_technologies": req_obj.tools_technologies,
        }
        rows = build_job_match_table(resume.raw_text, req_obj)
        match_rows = [{"requirement": r.requirement, "evidence": r.evidence, "status": r.status} for r in rows]
        match_summary = summarize_match(rows)

    ai_analysis = None
    ai_error = None
    if use_ai:
        try:
            ai_analysis = claude_client.analyze_resume_with_claude(
                resume_text=resume.raw_text,
                job_description=job_description,
                parsed_fields=resume.to_dict(),
                keyword_comparison=score.get("keyword_comparison"),
                target_role=target_role,
            )
        except ClaudeAPIError as exc:
            ai_error = str(exc)

    return FullAnalysisResult(
        parsed_resume=resume,
        score_breakdown=score,
        strength_analysis=strengths,
        job_requirements=requirements,
        match_summary=match_summary,
        match_rows=match_rows,
        ai_analysis=ai_analysis,
        ai_error=ai_error,
    )
