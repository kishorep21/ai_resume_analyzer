"""AI Resume Analyzer & ATS Score Generator - core modules package."""

__version__ = "1.0.0"
