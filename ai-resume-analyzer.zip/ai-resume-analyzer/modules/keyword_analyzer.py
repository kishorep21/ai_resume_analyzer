"""Job description keyword extraction and deterministic keyword matching.

All matching here is done with straightforward tokenization/overlap logic so
results are reproducible and explainable -- no AI calls are made in this
module.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Set

from .utils import normalize_token

# A small curated list of common tech / professional skills used to bias
# extraction toward genuine skills rather than arbitrary nouns. This is not
# exhaustive; it's combined with generic noun-phrase heuristics.
KNOWN_SKILLS = {
    "python", "java", "javascript", "typescript", "c++", "c#", "go", "rust",
    "sql", "nosql", "mongodb", "postgresql", "mysql", "redis",
    "aws", "azure", "gcp", "docker", "kubernetes", "terraform", "ci/cd",
    "react", "angular", "vue", "node.js", "django", "flask", "fastapi",
    "spring", "spring boot", "streamlit",
    "machine learning", "deep learning", "nlp", "computer vision",
    "langchain", "langgraph", "llm", "genai", "generative ai",
    "rag", "prompt engineering", "bedrock", "sagemaker",
    "tensorflow", "pytorch", "scikit-learn", "pandas", "numpy",
    "git", "github", "jira", "agile", "scrum",
    "rest api", "graphql", "microservices", "linux",
    "data structures", "algorithms", "system design",
    "communication", "leadership", "teamwork", "problem solving",
    "project management", "stakeholder management",
}

SOFT_SKILL_HINTS = {
    "communication", "leadership", "teamwork", "collaboration", "problem solving",
    "adaptability", "creativity", "time management", "critical thinking",
    "attention to detail", "stakeholder management", "mentoring", "ownership",
}

EDUCATION_RE = re.compile(
    r"\b(bachelor'?s?|master'?s?|b\.?tech|m\.?tech|b\.?sc|m\.?sc|mba|phd|degree)\b[^.\n]{0,80}",
    re.IGNORECASE,
)
EXPERIENCE_RE = re.compile(
    r"\b(\d+\+?\s*(?:-|to)?\s*\d*\+?)\s*(?:years?|yrs?)\b[^.\n]{0,60}", re.IGNORECASE
)

STOPWORDS = {
    "the", "and", "a", "an", "to", "of", "in", "for", "with", "on", "is", "are",
    "as", "by", "be", "will", "we", "you", "our", "your", "this", "that", "or",
    "at", "from", "such", "have", "has", "role", "team", "work", "working",
    "job", "candidate", "candidates", "responsibilities", "requirements",
    "experience", "skills", "ability", "strong", "excellent", "good",
}


@dataclass
class JobRequirements:
    """Structured requirements extracted from a job description."""

    required_skills: List[str] = field(default_factory=list)
    preferred_skills: List[str] = field(default_factory=list)
    technical_keywords: List[str] = field(default_factory=list)
    soft_skills: List[str] = field(default_factory=list)
    education_requirements: List[str] = field(default_factory=list)
    experience_requirements: List[str] = field(default_factory=list)
    tools_technologies: List[str] = field(default_factory=list)

    def all_keywords(self) -> Set[str]:
        combined = (
            self.required_skills
            + self.preferred_skills
            + self.technical_keywords
            + self.tools_technologies
        )
        return {normalize_token(k) for k in combined if k}


def _find_known_skills(text: str) -> List[str]:
    lower = text.lower()
    found = []
    for skill in KNOWN_SKILLS:
        pattern = r"(?<![a-z0-9])" + re.escape(skill) + r"(?![a-z0-9])"
        if re.search(pattern, lower):
            found.append(skill)
    return found


def _split_preferred_vs_required(text: str, skills: List[str]) -> tuple:
    """Naively bucket skills as 'preferred' if they appear in the same sentence
    as words like 'nice to have' / 'preferred' / 'plus', otherwise 'required'."""
    preferred_marker_re = re.compile(
        r"nice to have|preferred|good to have|\bplus\b|bonus|desirable", re.IGNORECASE
    )
    # Split into rough sentences so a marker anywhere in the sentence covers
    # skills mentioned earlier in that same sentence too.
    sentences = re.split(r"(?<=[.\n])", text)
    preferred_sentences = " ".join(s for s in sentences if preferred_marker_re.search(s)).lower()

    required, preferred = [], []
    for skill in skills:
        pattern = r"(?<![a-z0-9])" + re.escape(skill.lower()) + r"(?![a-z0-9])"
        if re.search(pattern, preferred_sentences):
            preferred.append(skill)
        else:
            required.append(skill)
    return required, preferred


def extract_job_requirements(job_description: str) -> JobRequirements:
    """Parse a job description into structured requirement buckets.

    Args:
        job_description: Raw job description text (may be empty).

    Returns:
        A :class:`JobRequirements` instance. All fields are empty lists if
        ``job_description`` is blank.
    """
    if not job_description or not job_description.strip():
        return JobRequirements()

    text = job_description.strip()
    all_skills = _find_known_skills(text)
    required, preferred = _split_preferred_vs_required(text, all_skills)

    soft_skills = [s for s in all_skills if s in SOFT_SKILL_HINTS]
    technical = [s for s in all_skills if s not in SOFT_SKILL_HINTS]

    education = [m.group(0).strip() for m in EDUCATION_RE.finditer(text)][:5]
    experience = [m.group(0).strip() for m in EXPERIENCE_RE.finditer(text)][:5]

    tools = [
        s for s in technical
        if s in {"aws", "azure", "gcp", "docker", "kubernetes", "terraform", "git",
                  "github", "jira", "jenkins", "bedrock", "sagemaker"}
    ]

    return JobRequirements(
        required_skills=sorted(set(required) - set(soft_skills)),
        preferred_skills=sorted(set(preferred) - set(soft_skills)),
        technical_keywords=sorted(set(technical)),
        soft_skills=sorted(set(soft_skills)),
        education_requirements=education,
        experience_requirements=experience,
        tools_technologies=sorted(set(tools)),
    )


@dataclass
class KeywordComparison:
    """Result of comparing resume text against job-description keywords."""

    matched: List[str] = field(default_factory=list)
    missing: List[str] = field(default_factory=list)
    additional: List[str] = field(default_factory=list)
    match_ratio: float = 0.0


def compare_keywords(resume_text: str, requirements: JobRequirements) -> KeywordComparison:
    """Compare resume text to job-description keywords.

    Args:
        resume_text: Full extracted resume text.
        requirements: Parsed job requirements.

    Returns:
        A :class:`KeywordComparison` with matched, missing, and additional
        keyword lists plus a 0-1 match ratio.
    """
    jd_keywords = requirements.all_keywords()
    if not jd_keywords:
        return KeywordComparison(matched=[], missing=[], additional=[], match_ratio=0.0)

    resume_lower = resume_text.lower()
    resume_skills_found = set(_find_known_skills(resume_text))
    resume_normalized = {normalize_token(s) for s in resume_skills_found}

    matched, missing = [], []
    for kw in sorted(jd_keywords):
        pattern = r"(?<![a-z0-9])" + re.escape(kw) + r"(?![a-z0-9])"
        if kw in resume_normalized or re.search(pattern, resume_lower):
            matched.append(kw)
        else:
            missing.append(kw)

    # Additional: skills present in resume that are relevant (known skills)
    # but were not asked for in the JD -- these can still strengthen a resume.
    additional = sorted(resume_normalized - jd_keywords)

    match_ratio = len(matched) / len(jd_keywords) if jd_keywords else 0.0
    return KeywordComparison(matched=matched, missing=missing, additional=additional, match_ratio=match_ratio)
