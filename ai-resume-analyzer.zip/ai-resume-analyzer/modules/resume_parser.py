"""Resume text extraction (PDF/DOCX) and structured field parsing.

Uses ``pypdf`` for PDF extraction and ``python-docx`` for DOCX extraction, then
applies regex/heuristic-based parsing to pull out structured resume sections.
No AI calls happen in this module -- everything here is deterministic.
"""

from __future__ import annotations

import io
import re
from dataclasses import dataclass, field
from typing import IO, List, Optional, Union

from .utils import ExtractionError, sanitize_text

try:
    from pypdf import PdfReader
except ImportError:  # pragma: no cover
    from PyPDF2 import PdfReader  # type: ignore

from docx import Document


# --------------------------------------------------------------------------
# Data model
# --------------------------------------------------------------------------


@dataclass
class ParsedResume:
    """Structured information extracted from a resume."""

    raw_text: str = ""
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    location: Optional[str] = None
    linkedin: Optional[str] = None
    github: Optional[str] = None
    summary: Optional[str] = None
    education: List[str] = field(default_factory=list)
    skills: List[str] = field(default_factory=list)
    experience: List[str] = field(default_factory=list)
    internships: List[str] = field(default_factory=list)
    projects: List[str] = field(default_factory=list)
    certifications: List[str] = field(default_factory=list)
    achievements: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "email": self.email,
            "phone": self.phone,
            "location": self.location,
            "linkedin": self.linkedin,
            "github": self.github,
            "summary": self.summary,
            "education": self.education,
            "skills": self.skills,
            "experience": self.experience,
            "internships": self.internships,
            "projects": self.projects,
            "certifications": self.certifications,
            "achievements": self.achievements,
        }

    def contact_completeness(self) -> float:
        """Fraction (0-1) of core contact fields that were found."""
        fields_to_check = [self.name, self.email, self.phone, self.location]
        found = sum(1 for f in fields_to_check if f)
        return found / len(fields_to_check)


# --------------------------------------------------------------------------
# Raw text extraction
# --------------------------------------------------------------------------


def extract_text_from_pdf(file_obj: Union[str, IO[bytes]]) -> str:
    """Extract raw text from a PDF file.

    Args:
        file_obj: A file path or a file-like object opened in binary mode.

    Returns:
        The concatenated text of all pages.

    Raises:
        ExtractionError: If the PDF cannot be read or contains no extractable text.
    """
    try:
        reader = PdfReader(file_obj)
        if getattr(reader, "is_encrypted", False):
            try:
                reader.decrypt("")
            except Exception as exc:  # noqa: BLE001
                raise ExtractionError("Unable to extract text from this file.") from exc

        pages_text = []
        for page in reader.pages:
            try:
                pages_text.append(page.extract_text() or "")
            except Exception:  # noqa: BLE001
                continue
        text = "\n".join(pages_text)
    except ExtractionError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise ExtractionError("Unable to extract text from this file.") from exc

    if not text.strip():
        raise ExtractionError(
            "Unable to extract text from this file. It may be a scanned image without "
            "selectable text."
        )
    return text


def extract_text_from_docx(file_obj: Union[str, IO[bytes]]) -> str:
    """Extract raw text from a DOCX file, including paragraphs and table cells.

    Args:
        file_obj: A file path or a file-like object.

    Returns:
        The extracted text.

    Raises:
        ExtractionError: If the DOCX cannot be read or contains no text.
    """
    try:
        document = Document(file_obj)
        parts: List[str] = []
        for paragraph in document.paragraphs:
            if paragraph.text.strip():
                parts.append(paragraph.text)
        for table in document.tables:
            for row in table.rows:
                for cell in row.cells:
                    if cell.text.strip():
                        parts.append(cell.text)
        text = "\n".join(parts)
    except Exception as exc:  # noqa: BLE001
        raise ExtractionError("Unable to extract text from this file.") from exc

    if not text.strip():
        raise ExtractionError("Unable to extract text from this file.")
    return text


def extract_text(filename: str, file_bytes: bytes) -> str:
    """Dispatch extraction based on file extension.

    Args:
        filename: Original filename (used to determine file type).
        file_bytes: Raw bytes of the uploaded file.

    Returns:
        Sanitized extracted text.

    Raises:
        ExtractionError: On unsupported type or extraction failure.
    """
    ext = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    stream = io.BytesIO(file_bytes)

    if ext == "pdf":
        raw = extract_text_from_pdf(stream)
    elif ext == "docx":
        raw = extract_text_from_docx(stream)
    else:
        raise ExtractionError("Please upload a PDF or DOCX resume.")

    return sanitize_text(raw)


# --------------------------------------------------------------------------
# Section detection
# --------------------------------------------------------------------------

SECTION_HEADERS = {
    "summary": [r"summary", r"professional summary", r"objective", r"profile"],
    "education": [r"education", r"academic (background|qualifications)"],
    "skills": [r"skills", r"technical skills", r"core competenc(y|ies)", r"key skills"],
    "experience": [r"(work |professional )?experience", r"employment history"],
    "internships": [r"internships?"],
    "projects": [r"projects?", r"academic projects?", r"personal projects?"],
    "certifications": [r"certifications?", r"licenses? (and|&) certifications?"],
    "achievements": [r"achievements?", r"awards?", r"honou?rs?"],
}

_ALL_HEADER_PATTERNS = [p for patterns in SECTION_HEADERS.values() for p in patterns]


def _is_section_header(line: str) -> Optional[str]:
    """Return the canonical section name if a line looks like a section header."""
    candidate = line.strip().strip(":").lower()
    if not candidate or len(candidate.split()) > 6:
        return None
    for section, patterns in SECTION_HEADERS.items():
        for pattern in patterns:
            if re.fullmatch(pattern, candidate) or re.fullmatch(pattern + r"s?", candidate):
                return section
    return None


def split_into_sections(text: str) -> dict:
    """Split resume text into named sections based on common headers.

    Returns a dict mapping section name -> list of non-empty lines under that
    header. Content before the first recognized header is discarded from the
    sections (but is still available via ``raw_text``).
    """
    sections: dict = {name: [] for name in SECTION_HEADERS}
    current: Optional[str] = None

    for line in text.split("\n"):
        stripped = line.strip()
        if not stripped:
            continue
        header = _is_section_header(stripped)
        if header:
            current = header
            continue
        if current:
            sections[current].append(stripped)

    return sections


def _split_entries(lines: List[str]) -> List[str]:
    """Group raw lines under a section into logical entries (bullets / blocks)."""
    entries: List[str] = []
    buffer: List[str] = []

    def flush():
        if buffer:
            entries.append(" ".join(buffer).strip())
            buffer.clear()

    bullet_re = re.compile(r"^[\-\u2022\*\u25CF\u25A0]\s*")
    for line in lines:
        if bullet_re.match(line):
            flush()
            entries.append(bullet_re.sub("", line).strip())
        elif re.match(r"^\d{4}\b", line) or re.search(r"\b(19|20)\d{2}\b.*\b(19|20)\d{2}\b", line):
            # Looks like a new dated entry (job/education block).
            flush()
            buffer.append(line)
        else:
            buffer.append(line)
    flush()
    return [e for e in entries if e]


# --------------------------------------------------------------------------
# Contact info extraction
# --------------------------------------------------------------------------

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
PHONE_RE = re.compile(r"(\+?\d{1,3}[\s.\-]?)?(\(?\d{3,4}\)?[\s.\-]?)\d{3}[\s.\-]?\d{3,4}")
LINKEDIN_RE = re.compile(r"(https?://)?(www\.)?linkedin\.com/[A-Za-z0-9\-_/%]+", re.IGNORECASE)
GITHUB_RE = re.compile(r"(https?://)?(www\.)?github\.com/[A-Za-z0-9\-_/%]+", re.IGNORECASE)
LOCATION_HINT_RE = re.compile(
    r"\b([A-Z][a-zA-Z.\-]+(?:\s[A-Z][a-zA-Z.\-]+)?,\s?[A-Z]{2,}[a-zA-Z]*)\b"
)


def _extract_name(text: str) -> Optional[str]:
    """Heuristic: the first non-empty line that looks like a person's name."""
    for line in text.split("\n")[:8]:
        stripped = line.strip()
        if not stripped:
            continue
        if EMAIL_RE.search(stripped) or PHONE_RE.search(stripped):
            continue
        if len(stripped) > 60:
            continue
        words = stripped.split()
        if 1 <= len(words) <= 5 and all(w[0].isupper() or not w[0].isalpha() for w in words if w):
            return stripped
    return None


def parse_contact_info(text: str) -> dict:
    """Extract contact fields (email, phone, linkedin, github, location, name)."""
    email_match = EMAIL_RE.search(text)
    phone_match = PHONE_RE.search(text)
    linkedin_match = LINKEDIN_RE.search(text)
    github_match = GITHUB_RE.search(text)
    location_match = LOCATION_HINT_RE.search(text[:600])  # look near the top

    return {
        "name": _extract_name(text),
        "email": email_match.group(0) if email_match else None,
        "phone": phone_match.group(0).strip() if phone_match else None,
        "linkedin": linkedin_match.group(0) if linkedin_match else None,
        "github": github_match.group(0) if github_match else None,
        "location": location_match.group(0) if location_match else None,
    }


def _extract_skills(lines: List[str]) -> List[str]:
    """Split skills section lines into individual skill tokens."""
    joined = " ".join(lines)
    # Skills are usually comma / pipe / bullet separated.
    parts = re.split(r"[,|;\u2022\n]| - ", joined)
    skills = []
    for part in parts:
        cleaned = part.strip(" .:-\t")
        if cleaned and len(cleaned) <= 40 and not cleaned.lower().startswith(("skills", "technical")):
            skills.append(cleaned)
    # De-duplicate while preserving order.
    seen = set()
    result = []
    for s in skills:
        key = s.lower()
        if key not in seen:
            seen.add(key)
            result.append(s)
    return result


# --------------------------------------------------------------------------
# Public entry point
# --------------------------------------------------------------------------


def parse_resume(filename: str, file_bytes: bytes) -> ParsedResume:
    """Extract and structure all resume fields from an uploaded file.

    Args:
        filename: Original filename, used to determine the parser to use.
        file_bytes: Raw file bytes.

    Returns:
        A populated :class:`ParsedResume`.

    Raises:
        ExtractionError: If the file can't be read or parsed.
    """
    text = extract_text(filename, file_bytes)
    if len(text.strip()) < 20:
        raise ExtractionError(
            "This resume appears to be empty or unreadable. Please upload a different file."
        )

    contact = parse_contact_info(text)
    sections = split_into_sections(text)

    resume = ParsedResume(
        raw_text=text,
        name=contact["name"],
        email=contact["email"],
        phone=contact["phone"],
        location=contact["location"],
        linkedin=contact["linkedin"],
        github=contact["github"],
        summary=" ".join(sections["summary"]).strip() or None,
        education=_split_entries(sections["education"]),
        skills=_extract_skills(sections["skills"]),
        experience=_split_entries(sections["experience"]),
        internships=_split_entries(sections["internships"]),
        projects=_split_entries(sections["projects"]),
        certifications=_split_entries(sections["certifications"]),
        achievements=_split_entries(sections["achievements"]),
    )
    return resume
