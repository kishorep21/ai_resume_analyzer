"""Tests for PDF and DOCX text extraction and resume parsing."""

import io
import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from docx import Document

from modules.resume_parser import (
    extract_text_from_docx,
    extract_text_from_pdf,
    parse_contact_info,
    parse_resume,
)
from modules.utils import ExtractionError

SAMPLE_RESUME_TEXT = """John Smith
john.smith@example.com | +1 555-123-4567 | Austin, TX
linkedin.com/in/johnsmith | github.com/johnsmith

Summary
Experienced Python developer with a background in building web applications
and APIs, focused on clean, maintainable code and strong testing practices.

Skills
Python, Django, FastAPI, PostgreSQL, Docker, AWS, Git

Experience
- Built and deployed a FastAPI microservice used by internal teams.
- Reduced API response time by optimizing database queries.

Education
B.Tech in Computer Science, XYZ University, 2020

Projects
- Personal finance tracker built with Django and PostgreSQL.

Certifications
AWS Certified Cloud Practitioner
"""


def _make_test_docx_bytes(text: str) -> bytes:
    doc = Document()
    for line in text.split("\n"):
        doc.add_paragraph(line)
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _make_test_pdf_bytes(text: str) -> bytes:
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import letter

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=letter)
    width, height = letter
    y = height - 50
    for line in text.split("\n"):
        c.drawString(50, y, line)
        y -= 15
        if y < 50:
            c.showPage()
            y = height - 50
    c.save()
    return buf.getvalue()


class TestDocxExtraction(unittest.TestCase):
    def test_extract_text_from_docx(self):
        data = _make_test_docx_bytes(SAMPLE_RESUME_TEXT)
        text = extract_text_from_docx(io.BytesIO(data))
        self.assertIn("John Smith", text)
        self.assertIn("FastAPI", text)

    def test_empty_docx_raises(self):
        doc = Document()
        buf = io.BytesIO()
        doc.save(buf)
        with self.assertRaises(ExtractionError):
            extract_text_from_docx(io.BytesIO(buf.getvalue()))


class TestPdfExtraction(unittest.TestCase):
    def test_extract_text_from_pdf(self):
        data = _make_test_pdf_bytes(SAMPLE_RESUME_TEXT)
        text = extract_text_from_pdf(io.BytesIO(data))
        self.assertIn("John Smith", text)
        self.assertIn("Skills", text)

    def test_invalid_pdf_raises(self):
        with self.assertRaises(ExtractionError):
            extract_text_from_pdf(io.BytesIO(b"not a real pdf"))


class TestContactInfoParsing(unittest.TestCase):
    def test_parse_contact_info(self):
        contact = parse_contact_info(SAMPLE_RESUME_TEXT)
        self.assertEqual(contact["email"], "john.smith@example.com")
        self.assertIn("555", contact["phone"])
        self.assertIn("linkedin.com/in/johnsmith", contact["linkedin"])
        self.assertIn("github.com/johnsmith", contact["github"])


class TestParseResume(unittest.TestCase):
    def test_parse_resume_from_docx(self):
        data = _make_test_docx_bytes(SAMPLE_RESUME_TEXT)
        resume = parse_resume("resume.docx", data)
        self.assertEqual(resume.email, "john.smith@example.com")
        self.assertTrue(any("python" in s.lower() for s in resume.skills))
        self.assertTrue(resume.education)
        self.assertTrue(resume.experience)

    def test_parse_resume_unsupported_extension(self):
        with self.assertRaises(ExtractionError):
            parse_resume("resume.txt", b"hello world")

    def test_parse_resume_empty_bytes(self):
        with self.assertRaises(ExtractionError):
            parse_resume("resume.pdf", b"")


if __name__ == "__main__":
    unittest.main()
