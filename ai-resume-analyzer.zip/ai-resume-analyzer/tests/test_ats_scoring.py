"""Tests for deterministic ATS scoring."""

import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from modules.ats_scoring import calculate_ats_score

RESUME_TEXT = """Jane Doe
jane.doe@example.com | +1 555-987-6543 | Seattle, WA
linkedin.com/in/janedoe | github.com/janedoe

Summary
GenAI engineer experienced with building multi-agent systems on AWS Bedrock
and LangGraph, with a strong Python background.

Skills
Python, AWS, LangGraph, LangChain, Docker, FastAPI, SQL

Experience
- Designed and deployed a multi-agent fraud detection system on AWS Bedrock,
  reducing manual review time by 40%.
- Built REST APIs with FastAPI serving 10k+ requests per day.

Education
B.Tech in Computer Science, ABC University, 2021

Projects
- RAG-based document search tool using LangChain and vector databases.

Certifications
AWS Certified Solutions Architect
"""

JOB_DESCRIPTION = """
We are looking for a GenAI Engineer with strong Python skills and experience
with AWS, LangGraph, and building multi-agent systems. Experience with Docker
and FastAPI is a plus. Bachelor's degree in Computer Science required.
3+ years of experience preferred.
"""


class TestCalculateAtsScore(unittest.TestCase):
    def test_returns_expected_keys(self):
        result = calculate_ats_score(RESUME_TEXT, JOB_DESCRIPTION)
        expected_keys = {
            "overall_score", "keyword_score", "skills_score", "experience_score",
            "project_score", "formatting_score", "structure_score",
            "education_score", "contact_score", "keyword_comparison",
        }
        self.assertTrue(expected_keys.issubset(result.keys()))

    def test_scores_are_within_bounds(self):
        result = calculate_ats_score(RESUME_TEXT, JOB_DESCRIPTION)
        for key in ("overall_score", "keyword_score", "skills_score", "experience_score",
                    "project_score", "formatting_score", "structure_score",
                    "education_score", "contact_score"):
            self.assertGreaterEqual(result[key], 0)
            self.assertLessEqual(result[key], 100)

    def test_relevant_resume_scores_reasonably_high(self):
        result = calculate_ats_score(RESUME_TEXT, JOB_DESCRIPTION)
        self.assertGreater(result["overall_score"], 50)
        self.assertGreater(result["keyword_score"], 40)

    def test_handles_missing_job_description(self):
        result = calculate_ats_score(RESUME_TEXT, "")
        self.assertEqual(result["keyword_score"], 0)
        self.assertGreaterEqual(result["overall_score"], 0)

    def test_empty_resume_raises(self):
        with self.assertRaises(ValueError):
            calculate_ats_score("", JOB_DESCRIPTION)

    def test_score_is_deterministic_not_random(self):
        r1 = calculate_ats_score(RESUME_TEXT, JOB_DESCRIPTION)
        r2 = calculate_ats_score(RESUME_TEXT, JOB_DESCRIPTION)
        self.assertEqual(r1["overall_score"], r2["overall_score"])
        self.assertEqual(r1, r2)

    def test_unrelated_resume_scores_lower_on_keywords(self):
        unrelated_resume = """Sam Lee
        sam.lee@example.com | 555-000-1111

        Summary
        Marketing specialist with experience in social media campaigns and
        content strategy.

        Skills
        SEO, Content Writing, Adobe Photoshop, Social Media Marketing

        Experience
        - Managed social media accounts for a retail brand.
        """
        result = calculate_ats_score(unrelated_resume, JOB_DESCRIPTION)
        relevant_result = calculate_ats_score(RESUME_TEXT, JOB_DESCRIPTION)
        self.assertLess(result["keyword_score"], relevant_result["keyword_score"])


if __name__ == "__main__":
    unittest.main()
