"""Tests for job-description keyword extraction and keyword matching."""

import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from modules.keyword_analyzer import compare_keywords, extract_job_requirements

JOB_DESCRIPTION = """
We need a Python Developer with experience in AWS, Docker, and Kubernetes.
Experience with React is a nice to have. Strong communication skills required.
Bachelor's degree required. 2+ years of experience.
"""

RESUME_WITH_MATCHES = """
Skilled Python developer with 3 years of experience building services on AWS
and deploying them with Docker. Comfortable with communication across teams.
"""

RESUME_NO_MATCHES = """
Experienced graphic designer skilled in Adobe Illustrator and branding.
"""


class TestExtractJobRequirements(unittest.TestCase):
    def test_extracts_required_and_preferred_skills(self):
        reqs = extract_job_requirements(JOB_DESCRIPTION)
        self.assertIn("python", reqs.required_skills)
        self.assertIn("aws", reqs.required_skills)
        self.assertIn("docker", reqs.required_skills)
        self.assertIn("react", reqs.preferred_skills)

    def test_extracts_soft_skills(self):
        reqs = extract_job_requirements(JOB_DESCRIPTION)
        self.assertIn("communication", reqs.soft_skills)

    def test_extracts_education_and_experience_requirements(self):
        reqs = extract_job_requirements(JOB_DESCRIPTION)
        self.assertTrue(reqs.education_requirements)
        self.assertTrue(reqs.experience_requirements)

    def test_empty_job_description_returns_empty_requirements(self):
        reqs = extract_job_requirements("")
        self.assertEqual(reqs.required_skills, [])
        self.assertEqual(reqs.all_keywords(), set())


class TestCompareKeywords(unittest.TestCase):
    def test_matched_and_missing_keywords(self):
        reqs = extract_job_requirements(JOB_DESCRIPTION)
        comparison = compare_keywords(RESUME_WITH_MATCHES, reqs)
        self.assertIn("python", comparison.matched)
        self.assertIn("aws", comparison.matched)
        self.assertIn("docker", comparison.matched)
        self.assertIn("kubernetes", comparison.missing)

    def test_no_match_resume(self):
        reqs = extract_job_requirements(JOB_DESCRIPTION)
        comparison = compare_keywords(RESUME_NO_MATCHES, reqs)
        self.assertEqual(comparison.matched, [])
        self.assertGreater(len(comparison.missing), 0)
        self.assertEqual(comparison.match_ratio, 0.0)

    def test_match_ratio_bounds(self):
        reqs = extract_job_requirements(JOB_DESCRIPTION)
        comparison = compare_keywords(RESUME_WITH_MATCHES, reqs)
        self.assertGreaterEqual(comparison.match_ratio, 0.0)
        self.assertLessEqual(comparison.match_ratio, 1.0)

    def test_empty_requirements_returns_empty_comparison(self):
        reqs = extract_job_requirements("")
        comparison = compare_keywords(RESUME_WITH_MATCHES, reqs)
        self.assertEqual(comparison.matched, [])
        self.assertEqual(comparison.missing, [])
        self.assertEqual(comparison.match_ratio, 0.0)


if __name__ == "__main__":
    unittest.main()
