# AI Resume Analyzer & ATS Score Generator

An AI-powered Streamlit application that analyzes a resume (PDF/DOCX), optionally
compares it against a job description, and produces a transparent ATS score,
keyword analysis, resume-strength diagnostics, AI-powered recommendations, and
a downloadable analysis report.

## Features

- **Resume upload & parsing** — PDF and DOCX support, extracting name, email,
  phone, location, LinkedIn, GitHub, summary, education, skills, experience,
  internships, projects, certifications, and achievements.
- **Job description analysis** — extracts required/preferred skills, technical
  keywords, soft skills, education requirements, experience requirements, and
  tools/technologies from pasted job description text.
- **Transparent ATS score (0–100)** — a weighted, fully deterministic score:
  - Keyword Match — 30%
  - Skills Match — 20%
  - Experience Relevance — 15%
  - Project Relevance — 10%
  - Resume Structure — 10%
  - Education/Certification Relevance — 5%
  - Formatting/ATS Compatibility — 5%
  - Contact Information Completeness — 5%

  The score is **never randomly generated** — every component is computed from
  the resume text (and job description, when provided).
- **Keyword analysis** — matched, missing, and additional-but-relevant keywords.
- **Resume strength analysis** — strong/weak/missing sections, generic
  statements, repeated words, weak action verbs, quantification opportunities,
  formatting problems, and ATS-unfriendly elements.
- **AI recommendations (Claude)** — actionable, resume-grounded suggestions for
  every major section, plus before/after bullet-point rewrites with a stated
  problem and reason for each change. Claude is instructed never to invent
  experience, employers, technologies, certifications, achievements, or
  metrics that aren't already in the resume.
- **AI-generated professional summary** — a 3–5 line summary tailored to a
  selected target role, generated only from resume content.
- **Job match analysis** — a requirement-by-requirement table showing the
  resume evidence (or "Not found") and a Match / Partial / Missing verdict.
- **Dashboard** — score cards, breakdowns, and a match percentage.
- **Downloadable report** — a Markdown report covering the full analysis.
- **Optional analysis history** — stored locally in SQLite (`data/analysis_history.db`).

## Architecture

```
app.py                     Streamlit UI: navigation, session state, page rendering
modules/
  resume_parser.py         PDF/DOCX text extraction + structured field parsing (regex/heuristics)
  keyword_analyzer.py       Job description parsing + deterministic keyword matching
  ats_scoring.py            calculate_ats_score(resume_text, job_description) -> dict
  job_matcher.py             Requirement -> evidence -> Match/Partial/Missing table
  claude_client.py           Anthropic API wrapper: prompts, JSON parsing/validation, error handling
  resume_analyzer.py         Deterministic strength analysis + full pipeline orchestration
  report_generator.py        Markdown analysis report builder
  utils.py                   Config loading, file validation, text sanitization, exceptions
```

Design principle: **all scoring and keyword matching is deterministic Python**.
Claude is used only for semantic analysis (summaries, qualitative strengths/
weaknesses, phrasing suggestions) and is always given the already-computed
keyword match data so its narrative stays consistent with the numeric score.

## Technology Stack

- **Frontend:** Streamlit
- **Backend:** Python 3.11+, modular architecture
- **PDF parsing:** `pypdf`
- **DOCX parsing:** `python-docx`
- **AI:** Anthropic Claude API (`anthropic` SDK)
- **Storage:** SQLite (optional analysis history)

## Installation

```bash
git clone <this-repo>
cd ai-resume-analyzer
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Environment Setup

Copy the example environment file and add your API key:

```bash
cp .env.example .env
```

Edit `.env`:

```env
ANTHROPIC_API_KEY=your_api_key_here
CLAUDE_MODEL=claude-sonnet-4-6
MAX_FILE_SIZE_MB=5
DB_PATH=data/analysis_history.db
```

Get an API key from the [Anthropic Console](https://console.anthropic.com/).
**Never commit your `.env` file** — it's already excluded via `.gitignore`.

If no API key is configured, the app still runs and shows deterministic
scoring, keyword analysis, and strength diagnostics; only the AI
Recommendations page and AI-generated summary require the key.

## Running the Application

```bash
streamlit run app.py
```

Then open the URL Streamlit prints (typically `http://localhost:8501`).

## Project Structure

```
ai-resume-analyzer/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
│
├── modules/
│   ├── __init__.py
│   ├── resume_parser.py
│   ├── ats_scoring.py
│   ├── keyword_analyzer.py
│   ├── job_matcher.py
│   ├── claude_client.py
│   ├── resume_analyzer.py
│   ├── report_generator.py
│   └── utils.py
│
├── data/
│   └── .gitkeep
│
└── tests/
    ├── __init__.py
    ├── test_parser.py
    ├── test_ats_scoring.py
    └── test_keyword_analyzer.py
```

## Example Workflow

1. Open the app and go to **Upload Resume**; upload a PDF or DOCX and pick a
   target role.
2. (Optional) Go to **Job Description** and paste a job posting.
3. Click **Run Analysis**.
4. Review results across **Resume Analysis**, **ATS Score**, **Keyword
   Analysis**, **AI Recommendations**, and **Job Match**.
5. Go to **Download Report** to export a Markdown summary of everything.

## Testing

The test suite generates an in-memory PDF fixture with `reportlab`, which is
a test-only dependency (not required to run the app itself):

```bash
pip install -r requirements-dev.txt
python -m unittest discover -s tests -v
```

Tests cover:
- PDF and DOCX text extraction (using generated in-memory fixtures)
- Contact-info and resume-field parsing
- Keyword extraction and matching (matched / missing / additional)
- ATS score calculation: valid output shape, score bounds, determinism
  (same input always produces the same score), and empty-resume handling
- Invalid/empty file handling

All 23 tests pass against this codebase.

## Security Notes

- API keys are read only from environment variables (`.env`); nothing is
  hardcoded.
- `.env` is excluded via `.gitignore`.
- Uploaded files are validated by extension and size before processing.
- Extracted text is sanitized (control characters stripped, whitespace
  normalized) before being used or sent to Claude.
- Resumes are not persisted to disk; only summary metadata (filename, score,
  target role, timestamp) is optionally stored in the local SQLite history.

## Error Handling

The app shows friendly messages instead of raw tracebacks, for example:

- "Please upload a PDF or DOCX resume."
- "Unable to extract text from this file."
- "Claude API is currently unavailable."
- "Please provide a job description for detailed job matching." (shown as an
  info banner rather than a hard error, since a job description is optional)

## Screenshots

_Add screenshots of the Home, ATS Score, and AI Recommendations pages here
after running the app locally._

## Future Improvements

- Support additional resume formats (e.g. `.rtf`, `.txt`).
- Multi-resume comparison against the same job description.
- Exportable PDF/DOCX version of the analysis report.
- Configurable scoring weights per industry or role.
- Multi-language resume support.
- Batch analysis mode for recruiters reviewing multiple candidates.
